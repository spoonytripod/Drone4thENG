using UnityEngine;
using UTMLatLngConverter;
using System;
using System.IO;
using System.Collections.Generic;


public class Drone : MonoBehaviour
{
    public GameObject DroneOBJ;    
    public GameObject GroundOBJ;    
    public GameObject HitOBJ;
    public GameObject DemoDroneOBJ;
    public GameObject DemoGroundOBJ;
    public GameObject DemoHitOBJ;

    // Initialize variables    
    private double offsetEast = 0;
    private double offsetNorth = 0;
    private double offsetHeight = 0;
    private int groundID = 0;
    private int droneID = 0;    
    private List<Dictionary<string, object>> ground;
    private List<Dictionary<string, object>> drone;
    private List<CalculationResult> calcResult = new List<CalculationResult>();
    RaycastHit hitInfo;

    void Awake()
    {
        Application.targetFrameRate = 60;
    }

    void Start()
    {
        Debug.ClearDeveloperConsole();

        // Load data from CSVs
        ground = ReadCSV.Read("ground");
        drone = ReadCSV.Read("drone");

        UTMtoUnity(ground); // convert UTM coord. of [ground] to Unity coord.
        GPStoUnity(drone); // convert GPS coord. of [drone] to Unity coord.
        SetPositionDrone(drone, droneID);

        // Target.Position(ground);
    }

    // Update is called once per frame
    void Update()
    {
        // Select DRONE POSITION
        if (Input.GetKeyDown(KeyCode.RightArrow))
        {
            if (droneID == drone.Count)
            {
                Debug.LogWarning("Drone index upper bound has been reached");
                Debug.Log("Image ID : " + drone[droneID]["number"]);
            }
            else
            {
                droneID += 1;
                SetPositionDrone(drone, droneID);
                Debug.Log("Image ID : " + drone[droneID]["number"]);
            }
        }
        if (Input.GetKeyDown(KeyCode.LeftArrow))
        {
            if (droneID == 0)
            {
                Debug.LogWarning("Drone index lower bound has been reached");
                Debug.Log("Image ID : " + drone[droneID]["number"]);
            }
            else
            {
                droneID -= 1;
                SetPositionDrone(drone, droneID);
                Debug.Log("Image ID : " + drone[droneID]["number"]);
            }
        }

        // Select TARGET(GROUND) POSITION
        if (Input.GetKeyDown(KeyCode.UpArrow))
        {
            if (groundID == (ground.Count - 1))
            {
                Debug.LogWarning("Ground target index upper bound has been reached");
                Debug.Log("Ground target ID : " + (groundID + 1));
            }
            else
            {
                groundID += 1;
                SetPositionGround(ground, groundID);
                Debug.Log("Ground target ID : " + ground[groundID]["station"]);
            }
        }
        if (Input.GetKeyDown(KeyCode.DownArrow))
        {
            if (groundID == 0)
            {
                Debug.LogWarning("Ground target index upper bound has been reached");
                Debug.Log("Ground target ID : " + (groundID + 1));
            }
            else
            {
                groundID -= 1;
                SetPositionGround(ground, groundID);
                Debug.Log("Ground target ID : " + ground[groundID]["station"]);
            }
        }

        // Calculate and save RESULT
        if (Input.GetKeyDown(KeyCode.Space))
        {
            PointUpdate();
            ResultUpdate();
        }

        if (Input.GetKeyDown(KeyCode.Return))
        {
            // �ڵ����� ��� �����Ϳ� ���� ��� ��� ����
            Debug.Log("Enter");

            for (droneID = 1; droneID < drone.Count; droneID++)
            {
                SetPositionDrone(drone, droneID);
                groundID = (int)drone[droneID]["target"] - 1;
                SetPositionGround(ground, groundID);

                PointUpdate();
                ResultUpdate();
            }

            Debug.Log("Calculation is done");
        }

        // Visualization
        if (Input.GetKeyDown(KeyCode.Slash))
        {
            this.transform.GetChild(0).gameObject.SetActive(false);
            GroundOBJ.gameObject.SetActive(false);
            HitOBJ.gameObject.SetActive(false);
            
            foreach (var result in calcResult)
            {
                Debug.Log("Drone ID : " + result.DroneID + " / Ground ID : " + (result.GroundID));                

                // Object rendering
                GameObject DemoDroneClone = Instantiate(DemoDroneOBJ, result.Position, result.Angle);
                DemoDroneClone.tag = "Clone";
                GameObject DemoGroundClone = Instantiate(DemoGroundOBJ, result.Ground, result.Angle); // Angle�� gameobject�� ��ü�̹Ƿ� ��� ����
                DemoGroundClone.tag = "Clone";
                GameObject DemoHitClone = Instantiate(DemoHitOBJ, result.Hit.point, result.Angle); // Angle�� gameobject�� ��ü�̹Ƿ� ��� ����
                DemoHitClone.tag = "Clone";

                // Line rendering
                LineRenderer LR = DemoDroneClone.GetComponent<LineRenderer>();
                LR.startColor = Color.red;
                LR.endColor = Color.red;
                LR.startWidth = 0.1f;
                LR.endWidth = 0.1f;
                LR.SetPosition(0, result.Position);
                LR.SetPosition(1, result.Hit.point);
            }
        }

        // Destroy all cloned game objects
        if (Input.GetKeyDown(KeyCode.Delete))
        {
            this.transform.GetChild(0).gameObject.SetActive(true);
            GroundOBJ.gameObject.SetActive(true);
            HitOBJ.gameObject.SetActive(true);

            GameObject[] cloneObjects;
            cloneObjects = GameObject.FindGameObjectsWithTag("Clone");

            for(int num = 0; num < cloneObjects.Length; num++)
            {
                Destroy(cloneObjects[num]);
            }
        }
    }

    class CalculationResult
    {
        public int DroneID;
        public int GroundID;
        public RaycastHit Hit;
        public Vector3 Position;
        public Quaternion Angle;
        public Vector3 Forward;
        public Vector3 Ground;
    }

    void UTMtoUnity(List<Dictionary<string, object>> UTMcoord)
    {
        offsetEast = (double)UTMcoord[0]["easting"];
        offsetNorth = (double)UTMcoord[0]["northing"];
        offsetHeight = (double)UTMcoord[0]["height"];

        for (int count = 0; count < UTMcoord.Count; count++)
        {
            UTMcoord[count]["easting"] = (double)UTMcoord[count]["easting"] - offsetEast;
            UTMcoord[count]["northing"] = (double)UTMcoord[count]["northing"] - offsetNorth;
            UTMcoord[count]["height"] = (double)UTMcoord[count]["height"] - offsetHeight;

            InfiniteLoopDetector.InfiniteLoopDetector.Run();
        }
    }

    void GPStoUnity(List<Dictionary<string, object>> GPScoord)
    {
        for (int count = 0; count < GPScoord.Count; count++)
        {
            var GPS = new LatLngCoords((double)GPScoord[count]["lat"], (double)GPScoord[count]["long"]);
            var UTM = CoordsConverter.ToUTM(GPS);
            double tempHeight = (double)GPScoord[count]["alt"];

            GPScoord[count]["lat"] = UTM.Easting - offsetEast; // - 1.297;
            GPScoord[count]["long"] = UTM.Northing - offsetNorth; // + 1.31;
            GPScoord[count]["alt"] = tempHeight - offsetHeight; // - 1.007;

            InfiniteLoopDetector.InfiniteLoopDetector.Run();
        }
    }

    void SetPositionDrone(List<Dictionary<string, object>> Drone, int ID)
    {
        // Drone object positioning
        this.transform.position = new Vector3(
            Convert.ToSingle(Drone[ID]["lat"]), 
            Convert.ToSingle(Drone[ID]["alt"]),
            Convert.ToSingle(Drone[ID]["long"]));
        this.transform.eulerAngles = new Vector3(
            Convert.ToSingle(Drone[ID]["pitch"]),
            Convert.ToSingle(Drone[ID]["head"]) + Convert.ToSingle(Drone[ID]["yaw"]),
            Convert.ToSingle(Drone[ID]["roll"]));
    }

    void SetPositionGround(List<Dictionary<string, object>> Ground, int ID)
    {
        GroundOBJ.transform.position = new Vector3(
                    Convert.ToSingle(Ground[ID]["easting"]),
                    Convert.ToSingle(Ground[ID]["height"]),
                    Convert.ToSingle(Ground[ID]["northing"]));
    }

    void PointUpdate()
    {
        if (Physics.Raycast(this.transform.position, this.transform.forward, out hitInfo))
        {
            Vector3 forward = transform.TransformDirection(Vector3.forward) * hitInfo.distance;
            Debug.DrawRay(transform.position, forward, Color.red, 10);
            HitOBJ.transform.position = hitInfo.point;
        }
        else
        {
            Debug.Log("No Hitted Object");
        }
    }

    void ResultUpdate()
    {
        var hitUTM = new UTMCoords(hitInfo.point.x + offsetEast, hitInfo.point.z + offsetNorth, 'S', 52);
        var hitGPS = CoordsConverter.ToLatLng(hitUTM);

        var droneUnity = this.transform.position;
        var droneUTM = new UTMCoords(droneUnity.x + offsetEast, droneUnity.z + offsetNorth, 'S', 52);
        var droneGPS = CoordsConverter.ToLatLng(droneUTM);

        List<double> list = new List<double>();
        list.Add(Convert.ToSingle(drone[droneID]["number"]));
        list.Add(groundID + 1);
        list.Add(hitInfo.point.x);
        list.Add(hitInfo.point.y);
        list.Add(hitInfo.point.z);
        list.Add(GroundOBJ.transform.position.x);
        list.Add(GroundOBJ.transform.position.y);
        list.Add(GroundOBJ.transform.position.z);
        MakeCSV.Save(list);

        CalculationResult result = new CalculationResult();
        result.DroneID = (int)drone[droneID]["number"];
        result.GroundID = (int)ground[groundID]["station"];
        result.Hit = hitInfo;
        result.Position = this.transform.position;
        result.Angle = this.transform.rotation;
        result.Forward = this.transform.forward;
        result.Ground = GroundOBJ.transform.position;
        calcResult.Add(result);

        //Debug.Log("Target Latitude : " + hitGPS.Latitude);
        //Debug.Log("Target Longitude : " + hitGPS.Longitude);
        //Debug.Log("Drone Latitude : " + droneGPS.Latitude);
        //Debug.Log("Drone Longitude : " + droneGPS.Longitude);
        //Debug.Log("Drone Height : " + (droneUnity.y + offsetHeight));
        //Debug.Log("Drone UTM(E) : " + droneUTM.Easting);
        //Debug.Log("Drone UTM(N) : " + droneUTM.Northing);
    }

    //void MakeCsv(List<double> data)
    //{
    //    FileStream fs = new FileStream("Assets/result.csv", FileMode.Append, FileAccess.Write);
    //    StreamWriter sw = new StreamWriter(fs, System.Text.Encoding.Unicode);
        
    //    // Image ID, Ground ID, Hit x, Hit y, Hit z, Ground x, Ground y, Ground z
    //    sw.WriteLine("{0}, {1}, {2}, {3}, {4}, {5}, {6}, {7}", 
    //        data[0], data[1], data[2], data[3], data[4], data[5], data[6], data[7]);
    //    sw.Close();
    //}
}